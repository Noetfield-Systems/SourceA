# Noetfield / SourceA / TrustField Entity Structure

**Status:** LOCKED v1  
**Saved:** 2026-06-28T06:23:35Z  
**Authority:** Founder-confirmed structure for public site copy, procurement/legal lines, and future agent context.

## Purpose

This document is the canonical reference for how the three public properties and their entities relate. Future agents must use this document before editing public copy, legal/procurement text, chatbot knowledge, or repo docs that describe Noetfield, SourceA, or TrustField.

## Canonical Structure

| Entity / brand | Public site | Canonical role | Public/legal wording |
| --- | --- | --- | --- |
| Noetfield Systems Inc | `https://noetfield.com` | Parent operating company / holding entity. Billing and contracting entity for SourceA. | "Noetfield Systems Inc." |
| SourceA | `https://sourcea.app` | Flagship product. Product-forward marketing surface. | "SourceA is a product of Noetfield Systems Inc." |
| TrustField Technologies Inc | `https://trustfield.ca` | Separate product lane. Distinct from SourceA and not the SourceA flagship product. | "TrustField Technologies Inc." |

## Site Responsibilities

### `sourcea.app`

SourceA leads the marketing story. Public hero, product pages, Forge Terminal, Brain chat, Kernel, and Proof Pack should stay product-forward and should not lead with the parent company.

Footer, procurement, security, terms, invoices, and legal/procurement areas must identify the backing entity:

> SourceA is a product of Noetfield Systems Inc.

Do not use bare legal ownership lines such as "© SourceA" without an entity-backed legal line nearby.

### `noetfield.com`

Noetfield is the parent/company view. It explains Noetfield Systems Inc as the operating company and may list SourceA as its flagship product.

Noetfield pages must not blur SourceA into the company itself. Use SourceA for the product; use Noetfield Systems Inc for parent/company, billing, and contracting language.

### `trustfield.ca`

TrustField is its own distinct lane and public property. It must stay separate from SourceA copy and should not be presented as the SourceA flagship product.

Use TrustField's own product language on TrustField surfaces. Legal/footer/procurement copy should use:

> TrustField Technologies Inc.

## Agent Rules

1. Product-forward marketing, entity-backed legals.
2. Do not put Noetfield Systems Inc in the SourceA hero unless the founder explicitly asks.
3. Do not write "© SourceA" without the Noetfield Systems Inc product/legal relationship.
4. Do not merge TrustField and SourceA. TrustField is a separate product lane.
5. Do not invent ownership, subsidiary, affiliate, or legal control facts beyond this document.
6. If a requested edit needs a legal ownership claim not stated here, stop and ask the founder.

## Known Footer Lines

SourceA:

> © 2026 Noetfield Systems Inc. · SourceA is a product of Noetfield Systems Inc. · noetfield.com

Noetfield:

> © 2026 Noetfield Systems Inc. · Parent operating company and billing/contracting entity · SourceA is the flagship product.

TrustField:

> © 2026 TrustField Technologies Inc. · Separate product lane · trustfield.ca
