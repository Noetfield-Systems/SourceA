#!/usr/bin/env python3
"""Move TrustField plan rows to the Noetfield Supabase project."""
from __future__ import annotations

import argparse
import json
import os
import subprocess
import sys
import urllib.error
import urllib.parse
import urllib.request
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[1]
BACKLOG = ROOT / "data/all-remaining-plan-backlog-v1.json"
MIGRATION = ROOT / "infra/supabase/noetfield/migrations/001_trustfield_plan_registry_v1.sql"
NOET_ENV = Path.home() / ".sourcea-secrets/noetfield.env"
NOET_DB = Path.home() / ".sourcea-secrets/noetfield-db.env"
SPINE_ENV = Path.home() / ".sourcea-secrets/portfolio-spine.env"
RECEIPT = Path.home() / ".sina/noetfield-trustfield-plan-registry-import-v1.json"
NOET_TABLE = "trustfield_plan_registry"
SPINE_TABLE = "sourcea_plan_registry"


def now() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def load_env_file(path: Path) -> dict[str, str]:
    out: dict[str, str] = {}
    if not path.is_file():
        return out
    for line in path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, _, val = line.partition("=")
        out[key.strip()] = val.strip().strip('"').strip("'")
    return out


def noet_cfg() -> dict[str, str]:
    cfg = {}
    cfg.update(load_env_file(NOET_ENV))
    cfg.update(load_env_file(NOET_DB))
    for key in ("SUPABASE_URL", "SUPABASE_ANON_KEY", "SUPABASE_SERVICE_ROLE_KEY", "SUPABASE_DB_PASSWORD"):
        env_key = f"NOETFIELD_{key}"
        if os.environ.get(env_key):
            cfg[key] = os.environ[env_key]
    return cfg


def spine_cfg() -> dict[str, str]:
    cfg = load_env_file(SPINE_ENV)
    for key in ("SUPABASE_URL", "SUPABASE_SERVICE_ROLE_KEY"):
        env_key = f"SPINE_{key}"
        if os.environ.get(env_key):
            cfg[key] = os.environ[env_key]
    return cfg


def public_cfg(cfg: dict[str, str]) -> dict[str, bool]:
    return {
        "supabase_url": bool(cfg.get("SUPABASE_URL")),
        "anon_key": bool(cfg.get("SUPABASE_ANON_KEY")),
        "service_key": bool(cfg.get("SUPABASE_SERVICE_ROLE_KEY")),
        "db_password": bool(cfg.get("SUPABASE_DB_PASSWORD")),
    }


def is_trustfield_item(item: dict[str, Any]) -> bool:
    return "trustfield" in json.dumps(item, sort_keys=True).lower()


def normalize_item(item: dict[str, Any]) -> dict[str, Any]:
    plan_id = str(item.get("plan_id") or item.get("id") or "").strip()
    title = str(item.get("title") or item.get("name") or plan_id).strip()
    priority_rank = item.get("priority_rank")
    try:
        priority_rank = int(priority_rank) if priority_rank is not None else None
    except (TypeError, ValueError):
        priority_rank = None
    source_registry = str(item.get("source_registry") or item.get("registry") or "")
    return {
        "plan_id": plan_id,
        "title": title,
        "status": str(item.get("status") or "") or None,
        "tier": str(item.get("tier") or "") or None,
        "lane": str(item.get("lane") or "trustfield") or "trustfield",
        "phase": str(item.get("phase") or "") or None,
        "workstream": str(item.get("workstream") or "") or None,
        "priority": str(item.get("priority") or "") or None,
        "priority_rank": priority_rank,
        "source_registry": source_registry or None,
        "source_schema": str(item.get("source_schema") or "") or None,
        "prompt_path": str(item.get("prompt_path") or "") or None,
        "source_path": str(item.get("prompt_path") or item.get("path") or source_registry or "") or None,
        "payload": item,
        "updated_at": now(),
    }


def load_rows() -> list[dict[str, Any]]:
    doc = json.loads(BACKLOG.read_text(encoding="utf-8"))
    rows = [normalize_item(item) for item in (doc.get("items") or []) if isinstance(item, dict) and is_trustfield_item(item)]
    return [row for row in rows if row["plan_id"] and row["title"]]


def request_json(
    cfg: dict[str, str],
    table: str,
    params: dict[str, str],
    *,
    method: str = "GET",
    body: Any | None = None,
) -> dict[str, Any]:
    base = str(cfg.get("SUPABASE_URL") or "").rstrip("/")
    key = str(cfg.get("SUPABASE_SERVICE_ROLE_KEY") or cfg.get("SUPABASE_ANON_KEY") or "")
    if not base or not key:
        return {"ok": False, "error": "supabase_not_configured"}
    data = None if body is None else json.dumps(body).encode("utf-8")
    url = f"{base}/rest/v1/{table}?{urllib.parse.urlencode(params, safe='(),.*')}"
    req = urllib.request.Request(
        url,
        data=data,
        method=method,
        headers={
            "apikey": key,
            "Authorization": f"Bearer {key}",
            "Content-Type": "application/json",
            "Accept": "application/json",
            "Prefer": "resolution=merge-duplicates,count=exact",
        },
    )
    try:
        with urllib.request.urlopen(req, timeout=45) as resp:
            raw = resp.read().decode("utf-8", errors="replace")
            parsed = json.loads(raw) if raw.strip() else []
            total = None
            content_range = resp.headers.get("Content-Range", "")
            if "/" in content_range:
                try:
                    total = int(content_range.rsplit("/", 1)[-1])
                except ValueError:
                    total = None
            return {"ok": 200 <= resp.status < 300, "status": resp.status, "body": parsed, "total": total}
    except urllib.error.HTTPError as exc:
        return {"ok": False, "status": exc.code, "error": exc.read().decode("utf-8", errors="replace")[:400]}
    except Exception as exc:
        return {"ok": False, "status": 0, "error": str(exc)[:240]}


def apply_migration(cfg: dict[str, str]) -> dict[str, Any]:
    probe = request_json(cfg, NOET_TABLE, {"select": "plan_id", "limit": "1"})
    if probe.get("ok"):
        return {"ok": True, "skipped": True, "reason": "table_exists"}
    password = str(cfg.get("SUPABASE_DB_PASSWORD") or "")
    ref = str(cfg.get("SUPABASE_PROJECT_ID") or "tkgpapowwplupyekpivy")
    if not password:
        return {"ok": False, "error": "noetfield_db_password_missing", "probe": probe}
    sql = MIGRATION.read_text(encoding="utf-8")
    try:
        import psycopg2  # noqa: WPS433
    except ImportError:
        subprocess.run([sys.executable, "-m", "pip", "install", "psycopg2-binary", "-q"], check=False, timeout=120)
        try:
            import psycopg2  # noqa: WPS433
        except ImportError:
            return {"ok": False, "error": "psycopg2_missing"}
    last_err = ""
    for host in (f"db.{ref}.supabase.co", "aws-0-ca-central-1.pooler.supabase.com"):
        for port in (5432, 6543):
            for user in (f"postgres.{ref}", "postgres"):
                try:
                    conn = psycopg2.connect(
                        host=host,
                        port=port,
                        user=user,
                        password=password,
                        dbname="postgres",
                        connect_timeout=12,
                        sslmode="require",
                    )
                    conn.autocommit = True
                    cur = conn.cursor()
                    cur.execute(sql)
                    cur.close()
                    conn.close()
                    return {"ok": True, "applied": True, "host": host, "port": port, "user": user}
                except Exception as exc:  # noqa: BLE001
                    last_err = str(exc)[:240]
    return {"ok": False, "error": last_err or "psycopg_connect_failed"}


def upsert_rows(cfg: dict[str, str], rows: list[dict[str, Any]], *, batch_size: int = 500) -> dict[str, Any]:
    imported = 0
    errors: list[dict[str, Any]] = []
    for offset in range(0, len(rows), batch_size):
        batch = rows[offset : offset + batch_size]
        res = request_json(cfg, NOET_TABLE, {"on_conflict": "plan_id"}, method="POST", body=batch)
        if not res.get("ok"):
            errors.append({"offset": offset, "status": res.get("status"), "error": res.get("error")})
            break
        imported += len(batch)
    return {"ok": not errors, "imported": imported, "errors": errors[:3]}


def count_table(cfg: dict[str, str], table: str) -> dict[str, Any]:
    return request_json(cfg, table, {"select": "plan_id", "limit": "1"})


def prune_spine(cfg: dict[str, str], rows: list[dict[str, Any]], *, batch_size: int = 200) -> dict[str, Any]:
    deleted = 0
    errors: list[dict[str, Any]] = []
    for offset in range(0, len(rows), batch_size):
        ids = [row["plan_id"] for row in rows[offset : offset + batch_size]]
        params = {"plan_id": f"in.({','.join(ids)})"}
        res = request_json(cfg, SPINE_TABLE, params, method="DELETE")
        if not res.get("ok"):
            errors.append({"offset": offset, "status": res.get("status"), "error": res.get("error")})
            break
        deleted += len(ids)
    return {"ok": not errors, "deleted_intended": deleted, "errors": errors[:3]}


def run(*, do_import: bool, do_prune_spine: bool) -> dict[str, Any]:
    rows = load_rows()
    noet = noet_cfg()
    spine = spine_cfg()
    migration = apply_migration(noet)
    out: dict[str, Any] = {
        "schema": "noetfield-trustfield-plan-registry-import-v1",
        "at": now(),
        "target": "noetfield",
        "target_ref": noet.get("SUPABASE_PROJECT_ID") or "tkgpapowwplupyekpivy",
        "table": NOET_TABLE,
        "source": str(BACKLOG.relative_to(ROOT)),
        "loaded_rows": len(rows),
        "noetfield_secrets": public_cfg(noet),
        "portfolio_spine_secrets": {"supabase_url": bool(spine.get("SUPABASE_URL")), "service_key": bool(spine.get("SUPABASE_SERVICE_ROLE_KEY"))},
        "migration": migration,
        "import": None,
        "prune_spine": None,
    }
    if do_import and migration.get("ok"):
        out["import"] = upsert_rows(noet, rows)
    if do_prune_spine:
        if not (out.get("import") or {}).get("ok"):
            out["prune_spine"] = {"ok": False, "skipped": True, "reason": "import_not_confirmed"}
        else:
            out["prune_spine"] = prune_spine(spine, rows)
    out["noetfield_count"] = count_table(noet, NOET_TABLE)
    out["portfolio_spine_count"] = count_table(spine, SPINE_TABLE)
    out["ok"] = bool(migration.get("ok")) and (not do_import or bool((out.get("import") or {}).get("ok")))
    if do_prune_spine:
        out["ok"] = bool(out["ok"]) and bool((out.get("prune_spine") or {}).get("ok"))
    RECEIPT.parent.mkdir(parents=True, exist_ok=True)
    RECEIPT.write_text(json.dumps(out, indent=2) + "\n", encoding="utf-8")
    out["receipt"] = str(RECEIPT)
    return out


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--import", dest="do_import", action="store_true")
    ap.add_argument("--prune-spine", action="store_true")
    ap.add_argument("--json", action="store_true")
    args = ap.parse_args()
    row = run(do_import=args.do_import, do_prune_spine=args.prune_spine)
    if args.json:
        print(json.dumps(row, indent=2))
    else:
        print(("OK" if row.get("ok") else "BLOCK") + f" rows={row['loaded_rows']} receipt={row['receipt']}")
    return 0 if row.get("ok") else 1


if __name__ == "__main__":
    raise SystemExit(main())

