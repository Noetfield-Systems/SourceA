# Supabase — Noetfield (dedicated project)

**Tier:** Production (module-scoped)  
**Cloud ref:** `tkgpapowwplupyekpivy`  
**Modules:** noetfield + TrustField

## Schema

| Schema | Purpose |
|--------|---------|
| `noetfield` | TLE receipts, decision audit, drift, copilot pilot |
| `trustfield` | TrustField operational data and plan registry lane |

## Secrets

`~/.sourcea-secrets/noetfield.env` — see `config.example.env`

## Rules

- **Not** portfolio-spine (`ldfruywifqnfpwsfgmdl`) — Noetfield has its own project.
- TrustField belongs on this Noetfield project (`tkgpapowwplupyekpivy`), not SourceA portfolio-spine.
- No cross-project JOINs with WitnessBC/portfolio-spine — async events only.
- Migrations in `migrations/` when added.

## Dashboard

https://supabase.com/dashboard/project/tkgpapowwplupyekpivy
