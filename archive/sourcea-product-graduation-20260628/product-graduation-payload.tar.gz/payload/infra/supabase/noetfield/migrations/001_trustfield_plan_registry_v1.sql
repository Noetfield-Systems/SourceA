-- TrustField plan registry — Noetfield Supabase project
-- Project: tkgpapowwplupyekpivy (Noetfield · Canada lane)
-- TrustField belongs on Noetfield, not portfolio-spine.

CREATE TABLE IF NOT EXISTS public.trustfield_plan_registry (
  plan_id TEXT PRIMARY KEY,
  title TEXT NOT NULL,
  status TEXT,
  tier TEXT,
  lane TEXT,
  phase TEXT,
  workstream TEXT,
  priority TEXT,
  priority_rank INTEGER,
  source_registry TEXT,
  source_schema TEXT,
  prompt_path TEXT,
  source_path TEXT,
  payload JSONB NOT NULL DEFAULT '{}'::jsonb,
  search_text TEXT GENERATED ALWAYS AS (
    coalesce(plan_id, '') || ' ' ||
    coalesce(title, '') || ' ' ||
    coalesce(lane, '') || ' ' ||
    coalesce(phase, '') || ' ' ||
    coalesce(workstream, '') || ' ' ||
    coalesce(priority, '')
  ) STORED,
  imported_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_trustfield_plan_registry_status
  ON public.trustfield_plan_registry (status);

CREATE INDEX IF NOT EXISTS idx_trustfield_plan_registry_lane_status
  ON public.trustfield_plan_registry (lane, status);

CREATE INDEX IF NOT EXISTS idx_trustfield_plan_registry_priority_rank
  ON public.trustfield_plan_registry (priority_rank);

CREATE INDEX IF NOT EXISTS idx_trustfield_plan_registry_source_registry
  ON public.trustfield_plan_registry (source_registry);

ALTER TABLE public.trustfield_plan_registry ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS trustfield_plan_registry_public_read ON public.trustfield_plan_registry;
CREATE POLICY trustfield_plan_registry_public_read ON public.trustfield_plan_registry
  FOR SELECT
  USING (true);

COMMENT ON TABLE public.trustfield_plan_registry IS
  'TrustField plan rows imported from disk SSOTs; hosted on Noetfield Supabase project.';

NOTIFY pgrst, 'reload schema';

